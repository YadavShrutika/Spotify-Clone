

console.log("Welcome to Spotify!");

let songIndex = 0;
let audioElement = new Audio('songs/1.mp3');
let masterPlay = document.getElementById('masterPlay');
let myProgressbar = document.getElementById('myProgressbar');
let gif = document.getElementById('gif'); // Reference to the existing gif
let songNameDisplay = document.getElementById('currentSongName'); // Song name span
let currentTimeDisplay = document.getElementById("currentTime");
let songDurationDisplay = document.getElementById("songDuration");


let songs = [
    { songName: "CHHAWA", filePath: "songs/mavale.mp3", coverPath: "covers/1.jpg" },
    { songName: "Jay Shivray", filePath: "songs/malhar.mp3", coverPath: "covers/2.jpg" },
    { songName: "Shivba", filePath: "songs/mavale.mp3", coverPath: "covers/3.jpg" },
    { songName: "Tanaji", filePath: "songs/tanaji.mp3", coverPath: "covers/4.jpg" },
    { songName: "Mhalhari", filePath: "songs/malhar.mp3", coverPath: "covers/5.jpg" },
    { songName: "Mavale", filePath: "songs/shivba.mp3", coverPath: "covers/6.jpg" },
];

//  Handle play/pause button
masterPlay.addEventListener('click', () => {
    if (audioElement.paused || audioElement.currentTime <= 0) {
        audioElement.play();
        masterPlay.classList.remove('fa-circle-play');
        masterPlay.classList.add('fa-circle-pause');
        gif.style.opacity = 1; //  Show gif
        gif.src = "playing.gif"; //  Restart GIF animation
        songNameDisplay.innerText = songs[songIndex].songName; // Update song name
    } else {
        audioElement.pause();
        masterPlay.classList.remove('fa-circle-pause');
        masterPlay.classList.add('fa-circle-play');
        gif.style.opacity = 0; //  Hide gif when paused
    }
});

//  Play song when clicking on an individual song
Array.from(document.getElementsByClassName("songlistPlay")).forEach((element, i) => {
    element.addEventListener("click", () => {
        songIndex = i;
        audioElement.src = songs[songIndex].filePath;
        audioElement.play();
        masterPlay.classList.remove('fa-circle-play');
        masterPlay.classList.add('fa-circle-pause');
        gif.style.opacity = 1; //  Show gif when playing new song
        gif.src = "playing.gif"; //  Restart GIF animation
        songNameDisplay.innerText = songs[songIndex].songName; //  Update song name
    });
});

//  Update progress bar as song plays
audioElement.addEventListener('timeupdate', () => {
    let progress = parseInt((audioElement.currentTime / audioElement.duration) * 100);
    myProgressbar.value = progress;

// Seek feature (user can drag progress bar)
myProgressbar.addEventListener('change', () => {
    if (!isNaN(audioElement.duration)) {
        audioElement.currentTime = (myProgressbar.value * audioElement.duration) / 100;
    }
});


let currentMinutes = Math.floor(audioElement.currentTime / 60);
    let currentSeconds = Math.floor(audioElement.currentTime % 60);
    if (currentSeconds < 10) currentSeconds = "0" + currentSeconds;
    currentTimeDisplay.innerText = `${currentMinutes}:${currentSeconds}`;

    // Format total duration
    let totalMinutes = Math.floor(audioElement.duration / 60);
    let totalSeconds = Math.floor(audioElement.duration % 60);
    if (totalSeconds < 10) totalSeconds = "0" + totalSeconds;
    if (!isNaN(totalMinutes) && !isNaN(totalSeconds)) {
        songDurationDisplay.innerText = `${totalMinutes}:${totalSeconds}`;
    }
});
